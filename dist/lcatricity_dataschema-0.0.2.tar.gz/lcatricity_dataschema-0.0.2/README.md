LCAtricity Data Schema
======================
__The Object Relational Model for the data storage layer of LCAtricity__

# Building
```bash
python3 -m pip install --upgrade build
python3 -m build
```